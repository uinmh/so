module GroupMoney {
	requires java.sql;
	requires java.desktop;
	requires com.oracle.database.jdbc;
}