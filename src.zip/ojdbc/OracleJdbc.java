package ojdbc;

public interface OracleJdbc {
	
    String URL = "jdbc:oracle:thin:@192.168.20.26:1521:xe";
    
    
    
    String USER = "scott";
    
    // Oracle DB에 접속하는 사용자 비밀번호
    
    String PASSWORD = "tiger";
}
